<template>
  <div class="location">当前位置：首页 <span>&nbsp;&gt;&nbsp;</span><b class="red"> 购物车</b></div>
</template>

<script setup>

</script>

<style lang="scss" scoped>

</style>